/*
File name: cd_account.cpp
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the implementation file of the cd_account.h
*/ 

#include <iostream>
#include <string>
#include "cd_account.h"
using namespace std;

//Constructor for initialization
CDAccount::CDAccount(): BankAccount(), interestRate(0.02){

  //left empty deliberately

}

//Constructor to make sure the name and rate is initialize
CDAccount::CDAccount(string the_name, double rate): BankAccount(the_name), interestRate(rate){

  //left empty

} 

//This function withdraw money
bool CDAccount::withdraw(double amount){

  if(amount <= 0){

    return false;

  }

  if(balance - amount - (balance * interestRate * 0.25) < 0){

      return false;

    }else{

    balance = balance - amount - (balance * interestRate * 0.25);
     
    }

    return true;

}
