/*
File name: money_marketing_account.cpp
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the header file of the bank_account.h
*/ 

#ifndef BANK_ACCOUNT_H
#define BANK_ACCOUNT_H
#include <iostream>
#include <string>
using namespace std;

class BankAccount{

 public:
  BankAccount();
  BankAccount(string the_name);
  virtual bool deposit(double amount);
  virtual bool withdraw(double amount);
  string getName();
  double getBalance();

 protected:
  string name;
  double balance; 


};

#endif
