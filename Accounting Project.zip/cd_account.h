/*
File name: cd_account.h
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the header file of the cd_account.cpp
*/ 

#ifndef CD_ACCOUNT_H
#define CD_ACCOUNT_H
#include <iostream>
#include <string>
#include "bank_account.h"
using namespace std;

class CDAccount : public BankAccount{

 public:
  CDAccount();
  CDAccount(string the_name, double rate);
  virtual bool withdraw(double amount); 

 protected:
  double interestRate;

};

#endif
