/*
File name: money_marketing_account.cpp
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the implementation file of the money_marketing_account.h
*/ 

#include <iostream>
#include <string>
#include "money_marketing_account.h"
using namespace std;

MoneyMarketingAccount::MoneyMarketingAccount(): BankAccount(), numWithdraws(0){

  //left empty deliberately

}

MoneyMarketingAccount::MoneyMarketingAccount(string the_name): BankAccount(the_name){

  //Left empty deliberately
}

bool MoneyMarketingAccount::withdraw(double amount){
  const double deductedFees = 1.50; //deductedcost

  //If the amount is smaller than zero, return false
  if(amount <= 0){

    return false;

  }

  //If the numWithdraws bigger than 2, balance need to deduct with deductedcost
  if(numWithdraws > 2){

    balance = balance - deductedFees;

  }

  //If balance smaller than the amount, return false
  if(balance - amount < 0){

    return false;

  }else{

    //if not smaller than the amount, it is sucessful
    balance = balance - amount;
    numWithdraws++; //Add 1 to the numWithdraws
    return true;

  }

}
