/*
File name: bank_account.cpp
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the implementation file for the base class bank_account.h
*/ 

#include<iostream>
#include <string>
#include "bank_account.h"

using namespace std;

//This constructor initialize the default setting
BankAccount::BankAccount(): name("Joe Doe"), balance(0.0){

  //Left blank deliberately

}

//This constructor make sure that name is initialize
BankAccount:: BankAccount(string the_name): name(the_name){

  //left blank deliberately

}


//Deposit amount of money and return whether or not it is successful
bool BankAccount::deposit(double amount){

  if(balance + amount < 0){

    return false;

  }else{

 balance = balance + amount;

  }

  return true;

}

//withdraw amount of money and test whether it is successful or not
bool BankAccount::withdraw(double amount){

  if(balance - amount < 0){

    return false;

  }else{

    balance = balance - amount;

  }

  return true;

}

//This function get the name
string BankAccount::getName(){

  return name;

}

//This function get the balance
double BankAccount::getBalance(){

  return balance;

}
