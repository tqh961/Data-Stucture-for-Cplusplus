/*
File name: money_marketing_account.h
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the header file of the money_marketing_account.cpp
*/ 

#ifndef MONEY_MARKETING_ACCOUNT_H
#define MONEY_MARKETING_ACCOUNT_H
#include <iostream>
#include <string>
#include "bank_account.h"
using namespace std;

class MoneyMarketingAccount : public BankAccount{

 public:
  MoneyMarketingAccount();
  MoneyMarketingAccount(string the_name);
  virtual bool withdraw(double amount);

 private:
  int numWithdraws;

};

#endif
