/*
File name: pqueue.cpp
Created by: Tan Qi Hao
Created on: 11/15/2019
Synopsis: This program is the implementation file for the base class pqueue.h
*/ 

#include<iostream>
#include <string>
#include <map>
#include "pqueue.h"

using namespace std;

//Template function for constructor PQueue
template<class T> 
PQueue<T>::PQueue(){
  //Intentionally leave blank
}

//Template function to add input and priority_num to map
template<class T>
void PQueue<T>::add(T input, int priority_num){

  //Decreased the decreasingDecimal everytime used it
  decreasingDecimal = decreasingDecimal / 2;  

  //Created a new priority number in double 
  //subtract every priority number with decreasingDecimal
  /*
    The reason to make a new priority number in double is to make sure
    that none of the keys in the map are the same, and still follow 
    ascending order. For it still followed ascending order, every integers 
    need to subtract with a decimal number that is constantly decreasing.
   */
  double double_priority_num = priority_num - decreasingDecimal;
  pairList[double_priority_num] = input;

}

template<class T>
T PQueue<T>::remove(){

  //Set a variable to the input items in the begin()
  T input_T = pairList.begin() -> second;

  //Erased the first items
  pairList.erase(pairList.begin());

  //Return the input_T
  return input_T;

}

template<class T>
bool PQueue<T>::empty(){

  //Return true, when the map is empty
  return pairList.empty();

}
