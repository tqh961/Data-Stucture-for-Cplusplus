/*
File name: pqueue.h
Created by: Tan Qi Hao
Created on: 12/4/2019
Synopsis: This program is the header file of pqueue
*/ 

#ifndef PQUEUE_H
#define PQUEUE_H
#include <iostream>
#include <string>
#include <map>
using namespace std;

//Template class PQueue
template<class T>
class PQueue{

 public:
  PQueue(); //default Constructor of PQueue
  void add(T input, int priority_num); //Function header of add
  T remove(); //Function header for remove()
  bool empty(); //Function header for empty()

 private:
  map<double, T> pairList; //Map structure to store the priority number and items

  double decreasingDecimal = 1.0; //This decimal need to be decrese everytime used

};

#endif
